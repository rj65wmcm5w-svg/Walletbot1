# GRAM Wallet Bot — @wal333ttt_bot

## Быстрый запуск на Railway (бесплатно)

1. Зайди на https://railway.app и войди через GitHub
2. New Project → Deploy from GitHub repo (загрузи эту папку)
3. В Variables добавь:
   - BOT_TOKEN = твой_новый_токен
   - WEBAPP_URL = https://claude.ai/artifact/KAwp17pVeY7yQQGpdHhtEK
4. Deploy — бот запустится автоматически

## Пакеты (настраиваются в bot.py → PACKAGES)
- 50 Stars  → 50 GRAM
- 150 Stars → 150 GRAM  
- 500 Stars → 500 GRAM

## Команды бота
- /start — приветствие + кнопка кошелька
- Callback "buy:0/1/2" — инвойс на Stars
- SuccessfulPayment → зачисление GRAM

## Важно
- Stars зачисляются Telegram-у, ты получаешь Stars на баланс бота
- Вывод Stars → TON через @wallet внутри Telegram
- В продакшне замени `balances` dict на реальную БД (SQLite/PostgreSQL)
